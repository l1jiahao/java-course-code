package argon.code;


public class Test {
    public static void main(String... args){
        CLibrary.instance.printf("%10d",21);
    }
}
