package argon.code;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;

public interface CLibrary extends Library {
    String libname= Platform.isWindows()?"msvcrt":"c";
    CLibrary instance= Native.load("msvcrt",CLibrary.class);

    void printf(String format,Object... args);
}
